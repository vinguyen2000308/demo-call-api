import lombok.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EWalletInfoDTO {
    private String code;
    private String message;
    private EwalletInfo ewalletInfo;

}
