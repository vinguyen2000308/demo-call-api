import lombok.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EwalletInfo {
    private Double balance;
    private String accountStatus;
    private String standardizedStatus;
    private String ewalletType;
    private String ewalletTypeId;
    private Boolean allowCancel;
}