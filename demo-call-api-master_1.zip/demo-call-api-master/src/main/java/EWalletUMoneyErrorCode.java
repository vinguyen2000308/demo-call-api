import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;

public enum EWalletUMoneyErrorCode {

    UMONEY_RESPONSE_CODE_SUCCESS(00000),
    UMONEY_ERROR_CODE_PHONE_NUMBER_IS_NULL(00001),
    UMONEY_ERROR_CODE_CORE_EXCEPTION(99999),
    UMONEY_ERROR_CODE_ISO_VALIDATION_ERROR(99998),
    UMONEY_ERROR_CODE_MISSING_REQUIRED_FIELD_IN_REQUEST(10130),
    UMONEY_ERROR_CODE_TIMOUT_TRANSACTION(10532),
    UMONEY_ERROR_CODE_WRONG_SIGNATURE_CORE(10112),
    UMONEY_ERROR_CODE_DUPLICATE_OR_ERROR_ACCOUNT(10113),
    UMONEY_ERROR_CODE_ACCOUNT_IS_BLOCKED_CAUSE_MORE_THAN_THREE_TIME_WRONG_PASSWORD(10114),
    UMONEY_ERROR_CODE_ACCOUNT_IS_BLOCKED_CAUSE_MORE_THAN_THREE_TIME_WRONG_SECRETE_PASSWORD(10115),
    UMONEY_ERROR_CODE_ACCOUNT_IS_BLOCKED_OR_WAITING_FOR_CANCELING(10117),
    UMONEY_ERROR_CODE_ACCOUNT_IS_BLOCKED(10118),
    UMONEY_ERROR_CODE_ACCOUNT_IS_REGISTERED_BUT_NOT_ACTIVATED(10122);

    private final int code;

    EWalletUMoneyErrorCode(int code) {
        this.code = code;
    }

    @JsonCreator
    public static String errorOf(int errorCode) {
        return Arrays.stream(values())
                .filter((errorCode1) -> errorCode1.code == errorCode)
                .findFirst().orElse(UMONEY_ERROR_CODE_CORE_EXCEPTION).toString();
    }

    @JsonValue
    public int toCode() {
        return this.code;
    }
}

