
public class Const {
    public static final String BCCS_VERSION = "BCCS2";
    public static final String E_WALLET_SERVICE_CHANNEL = "e-wallet-service";
    public static final int REFUNDED = 1;
    public static final Long MAX_CABLE_LENGTH = 500L;
    public static final String OK_MAX_NUM_SUB_CABLE_LENGTH = "OK_MAX_NUM_SUB_CABLE_LENGTH";

    public static final class Status {
        public static final Integer DRAFT = -1;
        public static final Integer ACTIVE = 2;
        public static final Integer INITIATED = 1;
        public static final Integer UPDATING = -3;
        public static final Integer INACTIVE = 0;
        public static final Integer CANCELED = -2;
    }

    public final static class HTTP_STATUS {
        public final static String BAD_REQUEST = "400";
        public final static String INTERNAL_ERROR = "500";
    }

    public static final class NIMS_PARAM {
        public static final Long LOCK = 1L;
        public static final Long UNLOCK = 0L;
    }

    public static final class WIRED_TECHNOLOGY {
        public static final String TECHNOLOGY_GPON = "4"; // gpon
        public static final String TECHNOLOGY_NOT_GPON = "-4"; // not gpon
        public static final String TECHNOLOGY_AON = "3"; // aon
        public static final String TECHNOLOGY_BRONZE = "1"; // cap dong
        public static final String TECHNOLOGY_CABLE = "2"; // cap dong truc
        public static final String DEFAULT_TECHNOLOGY = "0";
    }

    public static final class PROCESS_NAME {
        public static final String LOCK_OR_UNLOCK_INFRASTRUCTURE = "_LockOrUnlockInfrastructure";
    }

    public static final class TASK_VARIABLE {
        public static final String COMMAND = "command";
        public static final String SUCCESS = "success";
        public static final String MESSAGE = "message";
        public static final String ORDER_ID = "orderId";
        public static final String LINE_CODE = "lineCode";
        public static final String ORDER_ITEMS = "orderItems";
        public static final String RELATED_PRODUCT_ID = "relatedProductId";
        public static final String ACTION = "action";
        public static final String CONFIGURATION = "configuration";

    }

    public static final class TELECOMSERVICE {
        public static final Long FTTH = 28L;
        public static final Long WFTTH = 85L;
        public static final Long OTT_TV = 86L;
    }

    public static final class RESULT {
        public static final String PROCESS_RETURN_SUCCESS = "true";
    }

    public static final class SURVEY_ONLINE {
        public static final String OK = "OK";
        public static final String NOK = "NOK";
    }

    public static final class FAKE_CABLE_BOX_CODE {
        public static final String SUCCESS_CABLE_BOX_CODE = "I02-HNI0878";
        public static final String FAIL_CABLE_BOX_CODE = "I02-HNI0480";
    }

    public static final class SOAP {
        public static final String BCCS1_SOAP_OBJECT = "com.viettel.bccs3.ewallet.domain.soap";
    }


    public static final class EWALLET_CONST {
        // Response Code
        public static final String UMONEY_SUCCESS_CODE = "00000";
        public static final String UMONEY_SUCCESS_MESSAGE = "Success";
        public static final String UMONEY_EXCEPTION = "10001";

        // Status
        public static final Long STATUS_WAITING = 1l;
        public static final Long STATUS_FAIL = 4l;
        public static final Long STATUS_CANCEL_FAIL = 3L;

        // Action Code
        public static final String ACTION_CODE_REGISTER_EWALLET = "00";
        public static final String ACTION_CODE_REGISTER_CUSTOMER_INFO = "04";
        public static final String ACTION_CODE_CHANGE_CUSTOMER_INFO = "152";
        public static final String ACTION_CODE_TRANSFER_OF_RIGHTS = "1015";
        public static final String ACTION_CODE_CANCEL_ACCOUNT = "03";

        // API For UMoney
        public static final String UMONEY_NAMESPACE = "web";
        public static final String UMONEY_NAMESPACE_URI = "http://webservice.coreapp.ewallet.viettel.com/";
        public static final String UMONEY_GET_INFO_ACTION = "getInfo";

        // UMONEY API Request
        public static final String UMONEY_SOAP_ENDPOINT_API = "http://10.120.54.8:8280/services/EWalletProxyService?wsdl";
        public static final String UMONEY_ENDPOINT_API =  "http://183.182.100.174:8280/sendRequest";

        public static final String UMONEY_MIT_KEY = "0";
        public static final String UMONEY_MIT_VALUE = "0200";

        public static final String UMONEY_PROCESS_CODE_KEY = "3";
        public static final String UMONEY_PROCESS_CODE_VALUE = "311202";

        public static final String UMONEY_ACTION_CODE_KEY = "22";
        public static final String UMONEY_ACTION_CODE_VALUE = "7";

        public static final String UMONEY_PHONE_NUMBER_KEY = "34";

        public static final String UMONEY_PARTNER_CODE_KEY = "41";
        public static final String UMONEY_PARTNER_CODE_VALUE = "BCCS";

        public static final String UMONEY_SERVICE_CODE_KEY = "41";
        public static final String UMONEY_SERVICE_CODE_VALUE = "CHECK_INFO_CANCEL";


        // For UMoney
        public static final String UMONEY_BALANCE = "82";
        public static final String UMONEY_ACCOUNT_STATUS = "118";
        public static final String UMONEY_EWALLET_TYPE_ID = "20";
        public static final String UMONEY_STANDARDIZED_STATUS = "63";
        public static final String UMONEY_ALLOW_CANCEL = "61";


    }
}
